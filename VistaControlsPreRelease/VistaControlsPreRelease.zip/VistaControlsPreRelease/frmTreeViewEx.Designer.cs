namespace VistaControls
{
    partial class frmTreeViewEx
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.TreeNode treeNode1 = new System.Windows.Forms.TreeNode("Node14");
            System.Windows.Forms.TreeNode treeNode2 = new System.Windows.Forms.TreeNode("Node0", new System.Windows.Forms.TreeNode[] {
            treeNode1});
            System.Windows.Forms.TreeNode treeNode3 = new System.Windows.Forms.TreeNode("Node1");
            System.Windows.Forms.TreeNode treeNode4 = new System.Windows.Forms.TreeNode("Node6");
            System.Windows.Forms.TreeNode treeNode5 = new System.Windows.Forms.TreeNode("Node17");
            System.Windows.Forms.TreeNode treeNode6 = new System.Windows.Forms.TreeNode("Node20");
            System.Windows.Forms.TreeNode treeNode7 = new System.Windows.Forms.TreeNode("Node18", new System.Windows.Forms.TreeNode[] {
            treeNode6});
            System.Windows.Forms.TreeNode treeNode8 = new System.Windows.Forms.TreeNode("Node19");
            System.Windows.Forms.TreeNode treeNode9 = new System.Windows.Forms.TreeNode("Node13", new System.Windows.Forms.TreeNode[] {
            treeNode5,
            treeNode7,
            treeNode8});
            System.Windows.Forms.TreeNode treeNode10 = new System.Windows.Forms.TreeNode("Node7", new System.Windows.Forms.TreeNode[] {
            treeNode9});
            System.Windows.Forms.TreeNode treeNode11 = new System.Windows.Forms.TreeNode("Node8");
            System.Windows.Forms.TreeNode treeNode12 = new System.Windows.Forms.TreeNode("Node11");
            System.Windows.Forms.TreeNode treeNode13 = new System.Windows.Forms.TreeNode("Node26");
            System.Windows.Forms.TreeNode treeNode14 = new System.Windows.Forms.TreeNode("Node16", new System.Windows.Forms.TreeNode[] {
            treeNode13});
            System.Windows.Forms.TreeNode treeNode15 = new System.Windows.Forms.TreeNode("Node15", new System.Windows.Forms.TreeNode[] {
            treeNode14});
            System.Windows.Forms.TreeNode treeNode16 = new System.Windows.Forms.TreeNode("Node21");
            System.Windows.Forms.TreeNode treeNode17 = new System.Windows.Forms.TreeNode("Node25");
            System.Windows.Forms.TreeNode treeNode18 = new System.Windows.Forms.TreeNode("Node24", new System.Windows.Forms.TreeNode[] {
            treeNode17});
            System.Windows.Forms.TreeNode treeNode19 = new System.Windows.Forms.TreeNode("Node22", new System.Windows.Forms.TreeNode[] {
            treeNode18});
            System.Windows.Forms.TreeNode treeNode20 = new System.Windows.Forms.TreeNode("Node23");
            System.Windows.Forms.TreeNode treeNode21 = new System.Windows.Forms.TreeNode("Node12", new System.Windows.Forms.TreeNode[] {
            treeNode15,
            treeNode16,
            treeNode19,
            treeNode20});
            System.Windows.Forms.TreeNode treeNode22 = new System.Windows.Forms.TreeNode("Node9", new System.Windows.Forms.TreeNode[] {
            treeNode12,
            treeNode21});
            System.Windows.Forms.TreeNode treeNode23 = new System.Windows.Forms.TreeNode("Node10");
            System.Windows.Forms.TreeNode treeNode24 = new System.Windows.Forms.TreeNode("Node2", new System.Windows.Forms.TreeNode[] {
            treeNode4,
            treeNode10,
            treeNode11,
            treeNode22,
            treeNode23});
            System.Windows.Forms.TreeNode treeNode25 = new System.Windows.Forms.TreeNode("Node3");
            System.Windows.Forms.TreeNode treeNode26 = new System.Windows.Forms.TreeNode("Node4");
            System.Windows.Forms.TreeNode treeNode27 = new System.Windows.Forms.TreeNode("Node5");
            System.Windows.Forms.TreeNode treeNode28 = new System.Windows.Forms.TreeNode("Node27");
            System.Windows.Forms.TreeNode treeNode29 = new System.Windows.Forms.TreeNode("Node28");
            System.Windows.Forms.TreeNode treeNode30 = new System.Windows.Forms.TreeNode("Node42");
            System.Windows.Forms.TreeNode treeNode31 = new System.Windows.Forms.TreeNode("Node43");
            System.Windows.Forms.TreeNode treeNode32 = new System.Windows.Forms.TreeNode("Node29", new System.Windows.Forms.TreeNode[] {
            treeNode30,
            treeNode31});
            System.Windows.Forms.TreeNode treeNode33 = new System.Windows.Forms.TreeNode("Node30");
            System.Windows.Forms.TreeNode treeNode34 = new System.Windows.Forms.TreeNode("Node37");
            System.Windows.Forms.TreeNode treeNode35 = new System.Windows.Forms.TreeNode("Node38");
            System.Windows.Forms.TreeNode treeNode36 = new System.Windows.Forms.TreeNode("Node39");
            System.Windows.Forms.TreeNode treeNode37 = new System.Windows.Forms.TreeNode("Node45");
            System.Windows.Forms.TreeNode treeNode38 = new System.Windows.Forms.TreeNode("Node40", new System.Windows.Forms.TreeNode[] {
            treeNode37});
            System.Windows.Forms.TreeNode treeNode39 = new System.Windows.Forms.TreeNode("Node41");
            System.Windows.Forms.TreeNode treeNode40 = new System.Windows.Forms.TreeNode("Node31", new System.Windows.Forms.TreeNode[] {
            treeNode34,
            treeNode35,
            treeNode36,
            treeNode38,
            treeNode39});
            System.Windows.Forms.TreeNode treeNode41 = new System.Windows.Forms.TreeNode("Node32");
            System.Windows.Forms.TreeNode treeNode42 = new System.Windows.Forms.TreeNode("Node44");
            System.Windows.Forms.TreeNode treeNode43 = new System.Windows.Forms.TreeNode("Node33", new System.Windows.Forms.TreeNode[] {
            treeNode42});
            System.Windows.Forms.TreeNode treeNode44 = new System.Windows.Forms.TreeNode("Node34");
            System.Windows.Forms.TreeNode treeNode45 = new System.Windows.Forms.TreeNode("Node48");
            System.Windows.Forms.TreeNode treeNode46 = new System.Windows.Forms.TreeNode("Node49");
            System.Windows.Forms.TreeNode treeNode47 = new System.Windows.Forms.TreeNode("Node47", new System.Windows.Forms.TreeNode[] {
            treeNode45,
            treeNode46});
            System.Windows.Forms.TreeNode treeNode48 = new System.Windows.Forms.TreeNode("Node46", new System.Windows.Forms.TreeNode[] {
            treeNode47});
            System.Windows.Forms.TreeNode treeNode49 = new System.Windows.Forms.TreeNode("Node35", new System.Windows.Forms.TreeNode[] {
            treeNode48});
            System.Windows.Forms.TreeNode treeNode50 = new System.Windows.Forms.TreeNode("Node36");
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmTreeViewEx));
            this.treeViewEx = new System.Windows.Form.Vista.TreeViewEx();
            this.imageList = new System.Windows.Forms.ImageList(this.components);
            this.btnClose = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // treeViewEx
            // 
            this.treeViewEx.HotTracking = true;
            this.treeViewEx.ImageIndex = 0;
            this.treeViewEx.ImageList = this.imageList;
            this.treeViewEx.Location = new System.Drawing.Point(12, 12);
            this.treeViewEx.Name = "treeViewEx";
            treeNode1.ImageIndex = 1;
            treeNode1.Name = "Node14";
            treeNode1.Text = "Node14";
            treeNode2.Name = "Node0";
            treeNode2.Text = "Node0";
            treeNode3.ImageIndex = 2;
            treeNode3.Name = "Node1";
            treeNode3.Text = "Node1";
            treeNode4.Name = "Node6";
            treeNode4.Text = "Node6";
            treeNode5.Name = "Node17";
            treeNode5.Text = "Node17";
            treeNode6.ImageIndex = 5;
            treeNode6.Name = "Node20";
            treeNode6.Text = "Node20";
            treeNode7.ImageIndex = 3;
            treeNode7.Name = "Node18";
            treeNode7.Text = "Node18";
            treeNode8.ImageIndex = 4;
            treeNode8.Name = "Node19";
            treeNode8.Text = "Node19";
            treeNode9.Name = "Node13";
            treeNode9.Text = "Node13";
            treeNode10.Name = "Node7";
            treeNode10.Text = "Node7";
            treeNode11.Name = "Node8";
            treeNode11.Text = "Node8";
            treeNode12.Name = "Node11";
            treeNode12.Text = "Node11";
            treeNode13.Name = "Node26";
            treeNode13.Text = "Node26";
            treeNode14.Name = "Node16";
            treeNode14.Text = "Node16";
            treeNode15.Name = "Node15";
            treeNode15.Text = "Node15";
            treeNode16.Name = "Node21";
            treeNode16.Text = "Node21";
            treeNode17.Name = "Node25";
            treeNode17.Text = "Node25";
            treeNode18.Name = "Node24";
            treeNode18.Text = "Node24";
            treeNode19.Name = "Node22";
            treeNode19.Text = "Node22";
            treeNode20.Name = "Node23";
            treeNode20.Text = "Node23";
            treeNode21.Name = "Node12";
            treeNode21.Text = "Node12";
            treeNode22.Name = "Node9";
            treeNode22.Text = "Node9";
            treeNode23.Name = "Node10";
            treeNode23.Text = "Node10";
            treeNode24.Name = "Node2";
            treeNode24.Text = "Node2";
            treeNode25.Name = "Node3";
            treeNode25.Text = "Node3";
            treeNode26.Name = "Node4";
            treeNode26.Text = "Node4";
            treeNode27.ImageIndex = 2;
            treeNode27.Name = "Node5";
            treeNode27.Text = "Node5";
            treeNode28.Name = "Node27";
            treeNode28.Text = "Node27";
            treeNode29.ImageIndex = 7;
            treeNode29.Name = "Node28";
            treeNode29.Text = "Node28";
            treeNode30.ImageIndex = 5;
            treeNode30.Name = "Node42";
            treeNode30.Text = "Node42";
            treeNode31.ImageIndex = 3;
            treeNode31.Name = "Node43";
            treeNode31.Text = "Node43";
            treeNode32.Name = "Node29";
            treeNode32.Text = "Node29";
            treeNode33.Name = "Node30";
            treeNode33.Text = "Node30";
            treeNode34.Name = "Node37";
            treeNode34.Text = "Node37";
            treeNode35.Name = "Node38";
            treeNode35.Text = "Node38";
            treeNode36.Name = "Node39";
            treeNode36.Text = "Node39";
            treeNode37.Name = "Node45";
            treeNode37.Text = "Node45";
            treeNode38.Name = "Node40";
            treeNode38.Text = "Node40";
            treeNode39.Name = "Node41";
            treeNode39.Text = "Node41";
            treeNode40.ImageIndex = 2;
            treeNode40.Name = "Node31";
            treeNode40.Text = "Node31";
            treeNode41.Name = "Node32";
            treeNode41.Text = "Node32";
            treeNode42.Name = "Node44";
            treeNode42.Text = "Node44";
            treeNode43.ImageIndex = 7;
            treeNode43.Name = "Node33";
            treeNode43.Text = "Node33";
            treeNode44.Name = "Node34";
            treeNode44.Text = "Node34";
            treeNode45.Name = "Node48";
            treeNode45.Text = "Node48";
            treeNode46.Name = "Node49";
            treeNode46.Text = "Node49";
            treeNode47.Name = "Node47";
            treeNode47.Text = "Node47";
            treeNode48.Name = "Node46";
            treeNode48.Text = "Node46";
            treeNode49.Name = "Node35";
            treeNode49.Text = "Node35";
            treeNode50.Name = "Node36";
            treeNode50.Text = "Node36";
            this.treeViewEx.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode2,
            treeNode3,
            treeNode24,
            treeNode25,
            treeNode26,
            treeNode27,
            treeNode28,
            treeNode29,
            treeNode32,
            treeNode33,
            treeNode40,
            treeNode41,
            treeNode43,
            treeNode44,
            treeNode49,
            treeNode50});
            this.treeViewEx.SelectedImageIndex = 0;
            this.treeViewEx.Size = new System.Drawing.Size(140, 203);
            this.treeViewEx.TabIndex = 0;
            // 
            // imageList
            // 
            this.imageList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList.ImageStream")));
            this.imageList.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList.Images.SetKeyName(0, "audiosrv.dll_I00cb_0409.ico");
            this.imageList.Images.SetKeyName(1, "Chess.exe_I0080_0409.ico");
            this.imageList.Images.SetKeyName(2, "cleanmgr.exe_I0068_0409.ico");
            this.imageList.Images.SetKeyName(3, "connect.dll_I27d9_0409.ico");
            this.imageList.Images.SetKeyName(4, "desk.cpl_I0028_0409.ico");
            this.imageList.Images.SetKeyName(5, "explorer.exe_I0104_0409.ico");
            this.imageList.Images.SetKeyName(6, "imageres.dll_I00b1_0409.ico");
            this.imageList.Images.SetKeyName(7, "Journal.exe_I0068_0409.ico");
            this.imageList.Images.SetKeyName(8, "mspaint.exe_I0002_0409.ico");
            // 
            // btnClose
            // 
            this.btnClose.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnClose.Location = new System.Drawing.Point(72, 222);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(80, 27);
            this.btnClose.TabIndex = 1;
            this.btnClose.Text = "&Close";
            this.btnClose.UseVisualStyleBackColor = true;
            // 
            // frmTreeViewEx
            // 
            this.AcceptButton = this.btnClose;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnClose;
            this.ClientSize = new System.Drawing.Size(166, 261);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.treeViewEx);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmTreeViewEx";
            this.Text = "Enhanced TreeView";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Form.Vista.TreeViewEx treeViewEx;
        private System.Windows.Forms.ImageList imageList;
        private System.Windows.Forms.Button btnClose;
    }
}